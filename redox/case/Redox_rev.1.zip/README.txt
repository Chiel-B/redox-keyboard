                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2886662
Redox rev.1 by MattDB is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

<p align="center">
<img src="https://github.com/mattdibi/redox-keyboard/raw/master/img/redox-logo.png" alt="Redox logo" width="400"/>
</p>

*REduced ergoDOX custom mechanical keyboard.*

This project is a case for the first revision of the Redox custom ergonomic mechanical keyboard PCBs. The plate is compatible with Cherry MX and clones switches.

PCBs are available [here](https://falba.tech/product-category/keyboard-parts/redox-parts/), building informations and related projects can be found [in the Redox repository](https://github.com/mattdibi/redox-keyboard).

Additional informations:
- [Reddit post for discussion](https://www.reddit.com/r/MechanicalKeyboards/comments/8g1ihh/i_made_another_thing/)
- [Build log](https://imgur.com/a/a6ck2Nc)
- [Redox handwire](https://www.thingiverse.com/thing:2704567)
- [Hackaday Project page](https://hackaday.io/project/160610-redox-keyboard)

Materials needed to build a Redox rev.1.0 case:

| Qty | Item                                 | Notes                               |
|----:|--------------------------------------|-------------------------------------|
|   1 | Left top plate                       | File name: RedoxRev1TopLeft.STL     |
|   1 | Left bottom                          | File name: RedoxRev1BottomLeft.STL  |
|   1 | Right top plate                      | File name: RedoxRev1TopRight.STL    |
|   1 | Right bottom                         | File name: RedoxRev1BottomRight.STL |
|  10 | M3 x 8mm  screws                     |                                     |


Feel free to modify and remix the case design to best suit your needs, I added the **.dxf** and **.svg** files to this end. These files contains the PCB outline and the holes for the switches. Have fun designing your own case! ;)

**Update 23/09/2018**
I added the Redox Wireless plates to the thing files. For new build I suggest you to adopt these new ones as they are compatible with the Redox Rev.1 (wired version) and overall a better design.
*Note*: The wireless plates should be printed with the top facing downwards.

**Update 10/11/2018**
I uploaded a new version of the case's bottoms which makes the center screw hole more robust. I also removed the old plates files as I think the new version (aka WirelesRev1) is much better.